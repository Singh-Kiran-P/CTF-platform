declare module '*.vue' {
    import Vue from 'vue';
    export default Vue;
}
declare module 'vue-carousel';
declare module 'vue-easy-slider';