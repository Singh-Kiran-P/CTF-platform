enum Roles {
    VISITOR = 'visitor',
    PARTICIPANT = 'participant',
    CAPTAIN = 'captain',
    ORGANIZER = 'organizer'
}

export default Roles;
